package com.owner.omniai.data

import retrofit2.http.*

data class LoginRequest(val token:String,val device_id:String?=null)
data class LoginResponse(val ok:Boolean, val token:String, val expires_in:Long?=null)
data class ChatRequest(val conversation_id:String?=null,val text:String,val system_prompt:String?=null,val temperature:Double=.7,val top_p:Double=.9,val max_tokens:Int=512)
data class ChatResponse(val conversation_id:String,val answer:String,val intent:String?,val tool:String?,val model_id:String,val latency_s:Double?)
data class Conversation(val id:String,val title:String,val created_at:Double,val updated_at:Double)
data class Message(val id:String,val conversation_id:String,val role:String,val content:String,val model_id:String?,val created_at:Double)
data class ModelInfo(val id:String,val version:Int,val parent_id:String?,val status:String,val model_type:String?,val metrics:Any?,val created_at:Double)
data class Approval(val id:String,val kind:String,val payload:Map<String,Any?>,val status:String,val decision_note:String?,val created_at:Double)
data class MemoryItem(val id:String,val kind:String,val text:String,val importance:Double,val pinned:Boolean,val created_at:Double)
data class SystemStatus(val current_model:String?,val current_model_version:Int?,val training_thread_alive:Boolean,val controls:Map<String,Any>,val counts:Map<String,Any>)
data class TrainResponse(val status:String?=null,val skipped:String?=null,val reason:String?=null)

interface OmniApi {
 @POST("auth/login") suspend fun login(@Body body:LoginRequest):LoginResponse
 @POST("auth/logout") suspend fun logout(@Header("Authorization") auth:String):Map<String,Any>
 @POST("chat") suspend fun chat(@Body body:ChatRequest):ChatResponse
 @GET("conversations") suspend fun conversations():List<Conversation>
 @GET("conversations/{id}/messages") suspend fun messages(@Path("id") id:String):List<Message>
 @GET("models") suspend fun models():List<ModelInfo>
 @GET("status") suspend fun status():SystemStatus
 @GET("approvals") suspend fun approvals(@Query("status") status:String?=null):List<Approval>
 @POST("approvals/{id}/decide") suspend fun decide(@Path("id") id:String,@Body body:Map<String,String>):Approval
 @POST("approvals/{id}/execute") suspend fun execute(@Path("id") id:String):Map<String,Any>
 @POST("training/cycle") suspend fun trainingCycle(@Body body:Map<String,Any> = emptyMap()):TrainResponse
 @POST("training/start") suspend fun startTraining():Map<String,Any>
 @POST("training/stop") suspend fun stopTraining():Map<String,Any>
 @POST("models/rollback") suspend fun rollback(@Query("to_model_id") id:String?):ModelInfo
 @GET("controls") suspend fun controls():Map<String,Any>
 @POST("controls") suspend fun setControls(@Body body:Map<String,Any>):Map<String,Any>
 @GET("memory") suspend fun memories():List<MemoryItem>
 @POST("memory") suspend fun addMemory(@Body body:Map<String,Any>):Map<String,Any>
 @DELETE("memory/{id}") suspend fun forget(@Path("id") id:String):Map<String,Any>
}
